document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function(){
        document.getElementById('popup').style.display = 'block';
    }, 5000); // Adjust this number to change the time delay
});